package co.poli.edu.mtm.Model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Student {

	@Id
	private String id;
	private String firstname;
	private String lastname;
	private String phone;
	
	@ManyToMany
	@JoinTable(name="Course_Student",
	joinColumns = {@JoinColumn(name= "Student_id")},
	inverseJoinColumns = {@JoinColumn(name="Course_id")})
	Set<Course> DataSetCourse;

	
	
	public Student(String id, String firstname, String lastname, String phone, Set<Course> dataSetCourse) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.phone = phone;
		DataSetCourse = dataSetCourse;
	}
	
	public Student() {
		
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Set<Course> getDataSetCourse() {
		return DataSetCourse;
	}

	public void setDataSetCourse(Set<Course> dataSetCourse) {
		DataSetCourse = dataSetCourse;
	}
	
	
	
}
