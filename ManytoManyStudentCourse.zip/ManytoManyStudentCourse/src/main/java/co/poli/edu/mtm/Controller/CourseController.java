package co.poli.edu.mtm.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import co.poli.edu.mtm.Model.Course;

import co.poli.edu.mtm.Model.Student;
import co.poli.edu.mtm.Repository.CourseRepository;
import io.swagger.annotations.Api;

@Api(tags = {"Class: CourseController"}) //tag defined in SwaggerConfig.java
@RestController
@RequestMapping("/api/v1")
public class CourseController {

	@Autowired 
	CourseRepository courserepository;
	
	@GetMapping("/courses")
	public List<Course> getallcourses(){
		return courserepository.findAll();
	}
	
	@GetMapping("/course")
	public Course getCourseById(@PathVariable Integer idcourse ) {
		Course course = courserepository.findById(idcourse).get();
		return course;
		
	}

	@PostMapping("/courses")
	public Course createCourse(@RequestBody Course course) {
		return courserepository.save(course);
	}
	
	@PutMapping("/course/{idcourse}")
	public Course UpdateCourse(@PathVariable Integer idcourse, @RequestBody Course newcourse) {
		Course oldcourse = courserepository.findById(idcourse).get();
		
		oldcourse.setId(newcourse.getId());
		oldcourse.setName(newcourse.getName());
		oldcourse.setSchedule(newcourse.getSchedule());
		oldcourse.setDataSetStudent(newcourse.getDataSetStudent());
		
		courserepository.save(newcourse);
		
		return newcourse;
	}

	@DeleteMapping("/course/{idcourse}")
	public Course deletecourse(@PathVariable Integer idcourse) {
		Course delcourse = courserepository.findById(idcourse).get();
		delcourse.setDataSetStudent(null);
		courserepository.delete(delcourse);
		
		return delcourse;
	}
}
