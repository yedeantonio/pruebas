package co.poli.edu.mtm.Model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Course {

	@Id
	private Integer id;
	private String name;
	private String schedule;
	
	@ManyToMany (mappedBy = ("DataSetCourse"))
	Set<Student> DataSetStudent;	

	public Course() {
		
	}

	public Course(Integer id, String name, String schedule, Set<Student> dataSetStudent) {
		super();
		this.id = id;
		this.name = name;
		this.schedule = schedule;
		DataSetStudent = dataSetStudent;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSchedule() {
		return schedule;
	}

	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}

	public Set<Student> getDataSetStudent() {
		return DataSetStudent;
	}

	public void setDataSetStudent(Set<Student> dataSetStudent) {
		DataSetStudent = dataSetStudent;
	}
	
	
	
	
}
