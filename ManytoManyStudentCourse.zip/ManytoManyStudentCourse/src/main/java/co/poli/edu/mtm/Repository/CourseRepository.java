package co.poli.edu.mtm.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import co.poli.edu.mtm.Model.Course;
public interface CourseRepository extends JpaRepository<Course, Integer> {

}
