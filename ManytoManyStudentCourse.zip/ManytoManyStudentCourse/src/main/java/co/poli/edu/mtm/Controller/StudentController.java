package co.poli.edu.mtm.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.poli.edu.mtm.Repository.CourseRepository;
import co.poli.edu.mtm.Repository.StudentRepository;
import io.swagger.annotations.Api;
import co.poli.edu.mtm.Model.*;

@Api(tags = {"Class: StudentController"}) //tag defined in SwaggerConfig.java
@RestController
@RequestMapping("/api/v1")
public class StudentController {

	@Autowired
	StudentRepository studentrepository;
	
	@Autowired
	CourseRepository courserepository;
	
	@GetMapping("/students")
	public List<Student> getallstudents(){
		return studentrepository.findAll();
	}
	
	@GetMapping("/student")
	public Student getStudentById(@PathVariable String idstudent ) {
		Student student = studentrepository.findById(idstudent).get();
		return student;
		
	}

	@PostMapping("/students")
	public Student createStudents(@RequestBody Student student) {
		return studentrepository.save(student);
	}
	
	@PutMapping("/student/{idstudent}")
	public Student UpdateStudent(@PathVariable String idstudent, @RequestBody Student newstudent) {
		Student oldstudent = studentrepository.findById(idstudent).get();
		
		oldstudent.setId(newstudent.getId());
		oldstudent.setFirstname(newstudent.getFirstname());
		oldstudent.setLastname(newstudent.getLastname());
		oldstudent.setPhone(newstudent.getPhone());
		oldstudent.setDataSetCourse(newstudent.getDataSetCourse());
		
		studentrepository.save(newstudent);
		
		return newstudent;
	}

	@DeleteMapping("/student/{idstudent}")
	public Student deletestudent(@PathVariable String idstudent) {
		Student delstudent = studentrepository.findById(idstudent).get();
		delstudent.setDataSetCourse(null);
		studentrepository.delete(delstudent);
		
		return delstudent;
	}
	
	@PutMapping("/student/{ids}/{idc}")
	public Student AssociateStudentCourse(@PathVariable String ids, @PathVariable Integer idc) {
		Student student = studentrepository.findById(ids).get();
		Course course = courserepository.findById(idc).get();
		
		student.getDataSetCourse().add(course);
		course.getDataSetStudent().add(student);
		
		studentrepository.save(student);
		courserepository.save(course);
		
		return student;
	}
}
