package co.poli.edu.mtm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManytoManyStudentCourseApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManytoManyStudentCourseApplication.class, args);
	}

}
